# IPND Stage 2 Final Project

quiz_questions = ['''A __1__ is created with the def keyword. You specify the inputs a __1__
           takes by adding __2__ separated by commas between the parentheses. __1__s
           by default return __3__ if you don't specify the value to return. __2__ can
           be standard data types such as string,number, dictionary,tuple, and __4__ or
           can be more complicated such as objects and lambda functions.''',
       ''' The most basic data structure in Python is the __1__. Each element of a
           sequence is assigned a number - its position or __2__.The first __2__ is zero,
           the second __2__ is one, and so forth. Python has six built-in types of
           sequences,but the most common ones are lists and __3__, which we would see in
           this tutorial.You can __4__a list, but you cannot __4__ a string.''',
       ''' The main Python implementation, named CPython, is written in
           C meeting the __1__ standard. It compiles Python programs into
           intermediate __2__, which is executed by the __3__. CPython is
           distributed with a large standard library written in a mixture of C and
           Python. It is available in versions for many platforms, including Windows
           and most modern Unix-like systems. CPython was intended from almost its
           very conception to be __4__.''']

quiz_answers = [['function','arguments','none','lists'],
                    ['sequences','index','tuples','mutated'],
                    ['C18','bytecode','virtual machine','cross-platform']]

cont=1

def replace_answer(blank,question,word):
    '''This function finds each blank and replaces it with user input.Inputs are:
    blank, question and word entered by user. Output is question after the blank is filled with correct answer.'''
    pos1=question.find("__"+ str(blank))
    pos2=question.find("__",pos1+1)
    processed=question[pos1:pos2+2]
    new_question=question.replace(processed,word)
    print new_question
    question=new_question
    return question

def check_continue():
    '''Definition of check_continue function :This function checks to see if user wishes to continue playing the game
    input:user input with string 'yes' or 'no'
    output:cont=1 continues or quits game'''
    ques=raw_input("\nWould you like to continue? Type yes or no: ")
    if ques=='yes':
        print "Game continues ... "
        cont=1

    else:
        print "You have chosen to quit.Goodbye!"
        quit()

#End of check_continue function


#start of definition of play_game function
def play_game(question,answers):
    '''Code for logic of game. user gets maximum 6 attempts.
    input:takes two inputs- questions based on level and user_input for answers to quiz_questions.
    This function checks if user input matches correct answer...continues to next question..if all answers are correct, calls check_continue function
    if user_input does not match correct ans, prints incorrect input and allows 6 attempts
    after 6 attempts quits program.Output: the question paragraph with filled ans after every question'''
    flag=0
    counter= 0
    blank=1
    number_blanks = 4
    max_attempts = 6

    while blank <= number_blanks:
        while counter != max_attempts:
            word=raw_input("What should be sustituted for __"+str(blank)+"__? ")
            if word != answers[blank-1]:
                print "Incorrect input. Please try again."
                counter = counter + 1
            else:
                    print "Correct !!\n"
                    question = replace_answer(blank,question,word)
                    counter = 0
                    if blank == number_blanks:
                        print "Good job! You got them all.\n"
                        counter = max_attempts
                        flag=1
                    blank=blank+1
        if flag != 1:
            print "Out of tries... Game Over!"
            quit()

        else:
            check_continue()

#End of defining play_game function

def select_level():

    '''function select_level is defined here
    This function allows the user to select a level from easy , medium or hard
    input:user input of type string
    function stores user input in variable level_selected
    output:level_selected
    Based on level_selected, play_game function is called for executing quiz of either easy, medium or hard'''

    ans=raw_input("easy, medium and hard: ")
    ans = ans.lower()
    valid_levels = ['easy', 'medium', 'hard']
    level_selected = valid_levels.index(ans)


    if ans not in valid_levels:
        ans=raw_input("invalid response. Please enter easy, medium, or hard: ")
        level_selected = valid_levels.index(ans)

    if level_selected == 0:
        question = quiz_questions[0]
        answers = quiz_answers[0]
        print "\nYou have selected easy ! \nYou will get 6 guesses per blank.\nThe current paragraph reads as such:\n"
        print quiz_questions[0]
        play_game(quiz_questions[0], quiz_answers[0])

    elif level_selected == 1:
        question = quiz_questions[1]
        answers = quiz_answers[1]
        print "\nYou have selected medium ! \nYou will get 6 guesses per blank.\nThe current paragraph reads as such:\n"
        print quiz_questions[1]
        play_game(quiz_questions[1], quiz_answers[1])

    elif level_selected == 2:
        question = quiz_questions[2]
        answers = quiz_answers[2]
        print "\nYou have selected hard ! \nYou will get 6 guesses per blank.\nThe current paragraph reads as such:\n"
        print quiz_questions[2]
        play_game(quiz_questions[2], quiz_answers[2])

###End of select_level function



#start code for the game
#The computer begins executing the program from here
#The greeting statement is printed for the user and they are asked to select a difficulty level

while cont==1:
    print '\nWelcome to the game : Fill in the Blanks !\n'
    print "Please select the difficulty level by typing it in. Your options are :\n"

    select_level()

#End of game
